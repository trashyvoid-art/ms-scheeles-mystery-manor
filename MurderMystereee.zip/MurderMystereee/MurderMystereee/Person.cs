﻿using System;
namespace MurderMystereee
{
    public class Person
    {
        public string name;
        public string occupation;
        public Person()
        {
        }
    }
}
