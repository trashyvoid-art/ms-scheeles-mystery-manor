﻿using System;
using System.Collections.Generic;

namespace MurderMystereee
{
    public class Location
    {
        public string name;
        public string desc;
        // public Victim npc;

        public Location(string _name, string _desc)
        {
            name = _name;
            desc = _desc;
            //  npc = _npc;
        }
    }
}
