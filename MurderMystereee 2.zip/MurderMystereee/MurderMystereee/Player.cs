﻿using System;
using System.Collections.Generic;
using static System.Console;

namespace MurderMystereee
{
    public class Player : Person
    {
        public List<Item> inventory = new List<Item>();

        public Player()
        {
        }

    }
}
